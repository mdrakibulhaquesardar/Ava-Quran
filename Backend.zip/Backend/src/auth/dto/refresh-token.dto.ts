import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class RefreshTokenDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', description: 'The UUID Refresh Token issued during login' })
  @IsNotEmpty()
  @IsString()
  refreshToken: string;
}
